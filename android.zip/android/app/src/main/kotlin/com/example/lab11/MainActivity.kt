package com.example.lab11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
